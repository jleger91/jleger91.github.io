//package organizes your files
package com.example.cs360_projecttwo;

public class Item {
    //declare variables
    String name, type;
    int image;
    String id, quantity;
    String price;

    //constructor
    public Item(int image, String name, String id, String price, String quantity, String type) {
        this.image = image;
        this.name = name;
        this.id = id;
        this.price = price;
        this.quantity = quantity;
        this.type = type;
    }

    //getters and setters
    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
