//This file is the inventory screen of the app

//package organizes your files
package com.example.cs360_projecttwo;

//import dependencies and necessary libraries
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

//class to build screens in the app
public class SecondActivity extends AppCompatActivity {

    //declare variables
    Button addData;
    Button sortData;
    //creates an array list named items
    List<Item> items = new ArrayList<Item>();
    int[] images = {R.drawable.p1_leon, R.drawable.p2_zell, R.drawable.p3_dog,
                    R.drawable.p4_rinoa, R.drawable.p5_ward};
    int i = 0;

    dbInventory dbConnect;  //variable to manage database that stores information

    //overrides superclass method
    @Override
    //onCreate starts the activity
    protected void onCreate(Bundle savedInstanceState) {
        //run method from the super class
        super.onCreate(savedInstanceState);
        //sets the XML to view
        setContentView(R.layout.activity_second);

        //initialize variables
        addData = findViewById(R.id.addDataButton); //gets addData button from XML file
        sortData = findViewById(R.id.sortDataButton); //gets sortData button from XML file
        RecyclerView recyclerView = findViewById(R.id.recyclerView); //gets recyclerView from XML file
        dbConnect = new dbInventory(this);  //creates object to manage database

        //creates adapter object
        CustomAdapter adapter = new CustomAdapter(this, items);
        //sets adapter for recyclerView
        recyclerView.setAdapter(adapter);
        //sets layout manager for recyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        //when button is clicked to add a new inventory row
        addData.setOnClickListener(view -> {
            //notification that button was clicked
            Toast.makeText(SecondActivity.this, "Add Button click successful!", Toast.LENGTH_SHORT).show();

            setUpItems();
            //add new item to items array
            //items.add(new Item(images[0], "new item", 17409682, 10.99, 4, "candy"));
            //notify adapter that item was added
            adapter.notifyItemInserted(items.size() - 1);
        });

        //when button is clicked to sort data
        sortData.setOnClickListener(view -> {
            //notification that button was clicked
            Toast.makeText(SecondActivity.this, "Sort Button click successful!", Toast.LENGTH_SHORT).show();
            items.sort(Comparator.comparing(Item::getName));
            recyclerView.getAdapter().notifyDataSetChanged();
        });
    }

    //create all model classes for each of our items
    private void setUpItems(){
        String[] names = getResources().getStringArray(R.array.Name);
        String[] hp = getResources().getStringArray(R.array.HP);
        String[] mp = getResources().getStringArray(R.array.MP);
        String[] atk = getResources().getStringArray(R.array.ATK);
        String[] def = getResources().getStringArray(R.array.DEF);

        //sequentially add new items
        if(i < 5) {
            items.add(new Item(images[i], names[i], "HP: " + hp[i], "MP: " + mp[i], "ATK: " + atk[i], "DEF: " + def[i]));
            dbConnect.insertData(i);
            i += 1;
        } else {
            //reset to first item
            i = 0;
            items.add(new Item(images[i], names[i], "HP: " + hp[i], "MP: " + mp[i], "ATK: " + atk[i], "DEF: " + def[i]));
        }
    }
}