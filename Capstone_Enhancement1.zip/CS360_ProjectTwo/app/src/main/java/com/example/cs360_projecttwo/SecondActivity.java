//This file is the inventory screen of the app

//package organizes your files
package com.example.cs360_projecttwo;

//import dependencies and necessary libraries
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

//class to build screens in the app
public class SecondActivity extends AppCompatActivity {

    //declare variables
    Button addData;

    //overrides superclass method
    @Override
    //onCreate starts the activity
    protected void onCreate(Bundle savedInstanceState) {
        //run method from the super class
        super.onCreate(savedInstanceState);
        //sets the XML to view
        setContentView(R.layout.activity_second);

        //initialize variables
        addData = findViewById(R.id.addDataButton); //gets addData button from XML file
        RecyclerView recyclerView = findViewById(R.id.recyclerView); //gets recyclerView from XML file

        //creates an array list named items
        List<Item> items = new ArrayList<Item>();
        //adds new item to array list
        items.add(new Item("John Wick", 1, 10.99));

        //sets layout manager for recyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //creates adapter object
        CustomAdapter adapter = new CustomAdapter(items);
        //sets adapter for recyclerView
        recyclerView.setAdapter(adapter);

        //when button is clicked to add a new inventory row
        addData.setOnClickListener(view -> {
            //notification that button was clicked
            Toast.makeText(SecondActivity.this, "Button click successful!", Toast.LENGTH_SHORT).show();
            //add new item to items array
            items.add(new Item("John Wick", 1, 10.99));
            //notify adapter that item was added
            adapter.notifyItemInserted(items.size() - 1);
        });
    }
}