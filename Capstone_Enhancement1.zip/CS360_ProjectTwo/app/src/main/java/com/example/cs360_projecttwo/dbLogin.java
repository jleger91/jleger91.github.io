//this file is the database that holds username and password information for login screen

//package organizes your files
package com.example.cs360_projecttwo;

//import statements get necessary libraries and dependencies
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

//this class uses functionality from SQLite
public class dbLogin extends SQLiteOpenHelper {

    //constructor
    public dbLogin(@Nullable Context context) {
        super(context, "signup", null, 1);
    }

    //creates table containing all users
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create Table allusers(login TEXT primary key, password TEXT)");
    }

    //if the app version is upgraded
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){
        sqLiteDatabase.execSQL("drop table if exists allusers");
    }

    //inserts new data into the database
    public Boolean insertData(String login, String password){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("login", login);
        contentValues.put("password", password);
        long result = MyDatabase.insert("allusers", null, contentValues);

        return result != -1;
    }

    //checks that the login information is in database
    public Boolean checkLogin(String login){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from allusers where login = ?", new String[]{login});

        return cursor.getCount() > 0;
    }

    //checks that the login and password information is in database
    public Boolean checkLoginPassword(String login, String password){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from allusers where login = ? and password = ?", new String[]{login, password});

        return cursor.getCount() > 0;
    }

}
