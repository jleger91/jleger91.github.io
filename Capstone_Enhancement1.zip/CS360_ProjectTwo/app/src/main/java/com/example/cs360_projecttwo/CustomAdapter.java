//this file manages how data is displayed in the list or grid

//package organizes your files
package com.example.cs360_projecttwo;

//import statements get necessary libraries and dependencies
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<MyViewHolder> {
    //declare array
    private List<Item> items;

    public CustomAdapter(List<Item> items) {
        this.items = items;
    }

    @NonNull //indicates that field should never be null
    @Override //overrides super class
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //layoutInflater dynamically loads layouts at runtime
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_row_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    //binds data to a specific item in RecyclerView
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Item item = items.get(position); //get item position

        //when delete row button is clicked
        holder.deleteButton.setOnClickListener(v -> {
            items.remove(position); //remove item
            notifyItemRemoved(position); //notify that item was removed
            notifyItemRangeChanged(position, items.size()); //notify that the item range was changed
        });
    }

    @Override
    //method that returns size of items array
    public int getItemCount() {
        return items.size();
    }
}
