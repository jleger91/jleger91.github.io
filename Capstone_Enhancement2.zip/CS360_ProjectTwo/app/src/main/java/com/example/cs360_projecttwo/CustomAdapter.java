//this file manages how data is displayed in the list or grid

//package organizes your files
package com.example.cs360_projecttwo;

//import statements get necessary libraries and dependencies
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<MyViewHolder> {
    //declare array
    private List<Item> items;
    Context context;

    //public CustomAdapter(List<Item> items) {
    //    this.items = items;
    //}
    public CustomAdapter(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull //indicates that field should never be null
    @Override //overrides super class
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //layoutInflater dynamically loads layouts at runtime (giving a look to our rows)
        //View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_row_item, parent, false);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.text_row_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    //binds data to a specific item in RecyclerView
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        //assigning values to rows as they come onto screen
        //based on position of that recycler view

        holder.imageView.setImageResource(items.get(position).getImage());
        holder.nameView.setText(items.get(position).getName());
        String intId = Integer.toString(items.get(position).getId());
        holder.idView.setText(intId);
        String stringPrice = Double.toString(items.get(position).getPrice());
        holder.priceView.setText(stringPrice);
        String intQuantity = Integer.toString(items.get(position).getQuantity());
        holder.quantityView.setText(intQuantity);
        holder.typeView.setText(items.get(position).getType());


        Item item = items.get(position); //get item position

        //when delete row button is clicked
        holder.deleteButton.setOnClickListener(v -> {
            items.remove(position); //remove item
            notifyItemRemoved(position); //notify that item was removed
            notifyItemRangeChanged(position, items.size()); //notify that the item range was changed
        });
    }

    @Override
    //method that returns size of items array (how many items we have in total)
    public int getItemCount() {
        return items.size();
    }
}
