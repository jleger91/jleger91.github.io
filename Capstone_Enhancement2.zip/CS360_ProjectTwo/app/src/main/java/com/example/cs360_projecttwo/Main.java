//Inventory app created 9/21/25
// by Justin Leger, an SNHU student
//This file is the main login screen of the app

//package organizes your files
package com.example.cs360_projecttwo;

//import statements get necessary libraries and dependencies
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

//base class to build screens in app
public class Main extends Activity {

    //declare variables for the login screen
    EditText username;  //variable to enter username
    EditText password;  //variable to enter password
    Button loginButton;  //variable to log in
    Button signUpButton;  //variable to register new user
    dbLogin dbConnect;  //variable to manage database that stores information

    //overrides method from superclass
    @Override
    //overridden method onCreate used to start an activity
    //Bundle savedInstanceSate saves and restores state of activity
    protected void onCreate(@Nullable Bundle savedInstanceState){
        //runs method from super class in addition to the overridden one
        super.onCreate(savedInstanceState);
        //sets the XML to view to activity_main
        setContentView(R.layout.activity_main);

        //initialize variables
        username = findViewById(R.id.username); //gets username from XML file
        password = findViewById(R.id.password); //gets password from XML file
        loginButton = findViewById(R.id.loginButton); //gets login button from XML file
        signUpButton = findViewById(R.id.registerButton); //gets register button from XML file
        dbConnect = new dbLogin(this);  //creates object to manage database

        //when loginButton is clicked
        loginButton.setOnClickListener(view -> {

            //create String variables for username and password
            String my_username = username.getText().toString();
            String my_password = password.getText().toString();

            //if there is nothing written in the username or password fields
            if(my_username.isEmpty() || my_password.isEmpty()){
                //error notification that fields are empty
                Toast.makeText(Main.this, "Fields are empty!", Toast.LENGTH_SHORT).show();
            } else {
                //check validity of username and password against database
                Boolean checkCredentials = dbConnect.checkLoginPassword(my_username, my_password);

                //if the check passes
                if(checkCredentials){
                    //notification that the login is successful
                    Toast.makeText(Main.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    //prompt to send SMS about login
                    loginSuccessful();
                } else{
                    //error notification that login failed
                    Toast.makeText(Main.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //when user click the REGISTER button
        signUpButton.setOnClickListener(view -> {

            //create String variables for username and password
            String my_username = username.getText().toString();
            String my_password = password.getText().toString();

            //if there is nothing written in the username or password fields
            if(my_username.isEmpty() || my_password.isEmpty()){
                //error notification that fields are empty
                Toast.makeText(Main.this, "Fields are empty!", Toast.LENGTH_SHORT).show();
            }else{
                //check validity of username against database
                Boolean checkUserLogin = dbConnect.checkLogin(my_username);

                //if username is not already in database
                if(checkUserLogin == false){
                    //insert username into database
                    Boolean insert = dbConnect.insertData(my_username, my_password);

                    //if username and password insertion successful
                    if(insert == true){
                        //notification that username and password was registered
                        Toast.makeText(Main.this, "Signup Successful!", Toast.LENGTH_SHORT).show();
                        //if username and password insertion unsuccessful
                    } else {
                        //notification that username and password was not registered
                        Toast.makeText(Main.this, "Signup Failed!", Toast.LENGTH_SHORT).show();
                    }
                    //if username and password already in database
                }else{
                    //notification that username and password already exists
                    Toast.makeText(Main.this, "User already exists!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    //method to prompt SMS sending following the successful login
    private void loginSuccessful() {
        //create new builder object to create and display dialogs
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Grant SMS permission?"); //set title of dialog
        //set button for dialog
        builder.setPositiveButton("OK", (dialog, i) -> {
            dialog.dismiss(); //closes the dialog
            //retrieve default instance of SmsManager class
            SmsManager sms = SmsManager.getDefault();
            //notification pretends to send a message
            Toast.makeText(Main.this,"Sending message...",Toast.LENGTH_SHORT).show();
            //jump to second activity which is the inventory screen
            Intent intent = new Intent(Main.this, SecondActivity.class);
            startActivity(intent); //start inventory screen activity
        });
        //if user does not want to send SMS
        builder.setNegativeButton("cancel", (dialog, i) -> {
            dialog.dismiss(); //dismiss dialog box
            //jump to inventory screen
            Intent intent = new Intent(Main.this, SecondActivity.class);
            startActivity(intent); //start inventory screen activity
        });
        builder.show(); //display dialog box
    }
}

