//This file is used by CustomAdapter
//ViewHolder acts as a container for the views that represent each item in the list.
//Each element in the list is defined by a view holder object

//package organizes your files
package com.example.cs360_projecttwo;

//import statements get necessary libraries and dependencies
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {
    //grabs views from our text_row_item XML file

    //declare variables
    ImageView imageView;
    TextView nameView, idView, priceView, quantityView, typeView;
    Button deleteButton;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        //initialize variables
        imageView = itemView.findViewById(R.id.imageView2);
        nameView = itemView.findViewById(R.id.textName);
        idView = itemView.findViewById(R.id.textID);
        priceView = itemView.findViewById(R.id.textPrice);
        quantityView = itemView.findViewById(R.id.textQuantity);
        typeView = itemView.findViewById(R.id.textType);
        deleteButton = itemView.findViewById(R.id.deleteButton);
    }
}
