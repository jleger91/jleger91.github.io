package com.example.cs360_projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    Button addData;
    //dbInventory dbConnect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        addData = findViewById(R.id.addDataButton);
        //dbConnect = new dbInventory(this);

        //some of this information causes the crash

        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        List<Item> items = new ArrayList<Item>();
        items.add(new Item("John Wick", 1));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView.setAdapter(new CustomAdapter(getApplicationContext(), items));
        CustomAdapter adapter = new CustomAdapter(/*getApplicationContext(),*/ items);
        recyclerView.setAdapter(adapter);


        addData.setOnClickListener(view -> {
            Toast.makeText(SecondActivity.this, "Button click successful!", Toast.LENGTH_SHORT).show();
            items.add(new Item("John Wick", 1));
            //CustomAdapter.notifyDataSetChanged();
            adapter.notifyItemInserted(items.size() - 1);
        });
    }
}