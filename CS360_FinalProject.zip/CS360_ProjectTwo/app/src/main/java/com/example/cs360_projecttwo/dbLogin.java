package com.example.cs360_projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbLogin extends SQLiteOpenHelper {

    public dbLogin(@Nullable Context context) {
        super(context, "signup", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create Table allusers(login TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){
        sqLiteDatabase.execSQL("drop table if exists allusers");
    }

    public Boolean insertData(String login, String password){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("login", login);
        contentValues.put("password", password);
        long result = MyDatabase.insert("allusers", null, contentValues);

        return result != -1;
    }

    public Boolean checkLogin(String login){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from allusers where login = ?", new String[]{login});

        return cursor.getCount() > 0;
    }

    public Boolean checkLoginPassword(String login, String password){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from allusers where login = ? and password = ?", new String[]{login, password});

        return cursor.getCount() > 0;
    }

}
