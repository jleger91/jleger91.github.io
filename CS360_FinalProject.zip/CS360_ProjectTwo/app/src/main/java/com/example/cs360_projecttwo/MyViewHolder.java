package com.example.cs360_projecttwo;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {

    TextView nameView, quantityView;
    Button deleteButton;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        nameView = itemView.findViewById(R.id.textName);
        quantityView = itemView.findViewById(R.id.textQuantity);
        deleteButton = itemView.findViewById(R.id.deleteButton);
    }
}
