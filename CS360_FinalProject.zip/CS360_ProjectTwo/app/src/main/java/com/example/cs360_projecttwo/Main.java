package com.example.cs360_projecttwo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Main extends Activity {

    EditText username;
    EditText password;
    Button loginButton;
    Button signUpButton;
    dbLogin dbConnect;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.registerButton);
        dbConnect = new dbLogin(this);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //if info is in database, login with that info

                String der_username = username.getText().toString();
                String der_password = password.getText().toString();

                if(der_username.isEmpty() || der_password.isEmpty()){
                    Toast.makeText(Main.this, "Fields are empty!", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkCredentials = dbConnect.checkLoginPassword(der_username, der_password);

                    if(checkCredentials){
                        Toast.makeText(Main.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                        //now for the SMS part
                        loginSuccessful();
                        //Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
                        //startActivity(intent);
                    } else{
                        Toast.makeText(Main.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //using this code I created a user username and pass password
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //set new information to database
                String der_username = username.getText().toString();
                String der_password = password.getText().toString();

                if(der_username.isEmpty() || der_password.isEmpty()){
                    Toast.makeText(Main.this, "Fields are empty!", Toast.LENGTH_SHORT).show();
                }else{
                    //if(der_password.equals(confirmPassword)){
                    Boolean checkUserLogin = dbConnect.checkLogin(der_username);

                    if(checkUserLogin == false){
                        Boolean insert = dbConnect.insertData(der_username, der_password);

                        if(insert == true){
                            Toast.makeText(Main.this, "Signup Successful!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Main.this, "Signup Failed!", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(Main.this, "User already exists!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void loginSuccessful() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Grant SMS permission?");
        builder.setPositiveButton("OK", (dialog, i) -> {
            dialog.dismiss();
            SmsManager sms = SmsManager.getDefault();
            Toast.makeText(Main.this,"Sending message...",Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Main.this, SecondActivity.class);
            startActivity(intent);
        });
        builder.setNegativeButton("cancel", (dialog, i) -> {
            dialog.dismiss();
            Intent intent = new Intent(Main.this, SecondActivity.class);
            startActivity(intent);
        });
        builder.show();
    }
}

